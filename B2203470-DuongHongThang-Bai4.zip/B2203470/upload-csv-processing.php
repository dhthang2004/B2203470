<?php
if (isset($_POST["submit"])) { // Kiểm tra xem form đã được gửi chưa
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Kiểm tra xem có file được upload không
    if ($_FILES["fileToUpload"]["error"] === UPLOAD_ERR_OK) {
        // Di chuyển file upload vào thư mục
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "File " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " đã được upload.";

            // Kết nối CSDL
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "qlbanhang";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Kiểm tra kết nối
            if ($conn->connect_error) {
                die("Kết nối thất bại: " . $conn->connect_error);
            }

            // Đọc dữ liệu từ file CSV và insert vào CSDL
            if (($handle = fopen($target_file, "r")) !== FALSE) {
                fgetcsv($handle); // Bỏ qua dòng tiêu đề
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    // Đảm bảo rằng các trường dữ liệu đã đủ
                    if (count($data) == 6) { // 6 trường: id, fullname, email, Birthday, password, img_profile
                        // Câu lệnh SQL
                        $sql = "INSERT INTO customers (id, fullname, email, Birthday, password, img_profile) VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $hashed_password = password_hash($data[4], PASSWORD_DEFAULT);

                        // Kiểm tra xem câu lệnh có thành công không
                        if ($stmt === false) {
                            echo "Lỗi trong câu lệnh SQL: " . $conn->error;
                            continue; // Bỏ qua dòng này và tiếp tục
                        }

                        // Liên kết các tham số
                        $stmt->bind_param("isssss", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5]);
                        $stmt->execute();
                    } else {
                        echo "Dòng dữ liệu không hợp lệ: " . implode(", ", $data) . "<br>";
                    }
                }
                fclose($handle);
                echo "Dữ liệu đã được thêm thành công vào cơ sở dữ liệu.";
            } else {
                echo "Không thể mở file.";
            }

            // Đóng kết nối
            $conn->close();
        } else {
            echo "Xin lỗi, có lỗi xảy ra khi upload file.";
        }
    } else {
        echo "Xin lỗi, không có file nào được chọn hoặc có lỗi xảy ra khi upload.";
    }
} else {
    echo "Không có dữ liệu nào được gửi.";
}
?>
<?php
session_start(); // Bắt đầu phiên làm việc

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$sql = "SELECT id, fullname, email FROM customers WHERE email = '".$_POST["email"]."' AND password = '".md5($_POST["pass"])."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Lưu giá trị vào biến phiên
    $_SESSION["user"] = $row['email'];
    $_SESSION["fullname"] = $row['fullname'];
    $_SESSION["id"] = $row['id'];
    
    header('Location: homepage.php');
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
    header('Refresh: 3;url=login.php');
}

$conn->close();
?>
<?php
session_start();

// Kiểm tra xem người dùng đã đăng nhập chưa, nếu chưa thì chuyển hướng về trang đăng nhập
// if (!isset($_SESSION["user"])) {
//     header("Location: login.php");
//     exit();
// }

// Kết nối đến CSDL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Xử lý khi người dùng gửi form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ form
    $old_password = $_POST["old_password"];
    $new_password = $_POST["new_password"];
    $confirm_password = $_POST["confirm_password"];

    // Lấy thông tin người dùng từ Session
    $user_email = $_SESSION["user"];

    // Kiểm tra mật khẩu cũ
    $sql_check_password = "SELECT password FROM customers WHERE email = '$user_email'";
    $result_check_password = $conn->query($sql_check_password);

    if ($result_check_password->num_rows > 0) {
        $row = $result_check_password->fetch_assoc();
        $hashed_old_password = md5($old_password);

        if ($hashed_old_password == $row["password"]) {
            // Kiểm tra mật khẩu mới và xác nhận mật khẩu mới
            if ($new_password == $confirm_password) {
                // Kiểm tra xem mật khẩu mới có giống mật khẩu cũ không
                if ($hashed_old_password != md5($new_password)) {
                    // Băm mật khẩu mới và cập nhật vào CSDL
                    $hashed_new_password = md5($new_password);
                    $sql_update_password = "UPDATE customers SET password = '$hashed_new_password' WHERE email = '$user_email'";

                    if ($conn->query($sql_update_password) === TRUE) {
                        echo "Mật khẩu đã được cập nhật thành công!";
                    } else {
                        echo "Lỗi khi cập nhật mật khẩu: " . $conn->error;
                    }
                } else {
                    echo "Mật khẩu mới phải khác mật khẩu cũ.";
                }
            } else {
                echo "Mật khẩu mới và xác nhận mật khẩu mới không khớp.";
            }
        } else {
            echo "Mật khẩu cũ không đúng.";
        }
    } else {
        echo "Lỗi truy vấn CSDL: " . $conn->error;
    }

    // Đóng kết nối
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa mật khẩu</title>
</head>

<body>
    <h2>Chỉnh sửa mật khẩu</h2>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="old_password">Mật khẩu cũ:</label>
        <input type="password" name="old_password" required><br>

        <label for="new_password">Mật khẩu mới:</label>
        <input type="password" name="new_password" required><br>

        <label for="confirm_password">Xác nhận mật khẩu mới:</label>
        <input type="password" name="confirm_password" required><br>

        <input type="submit" value="Cập nhật">
    </form>
</body>

</html>